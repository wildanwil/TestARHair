# Hair Try-On (prototype)

Prototype aplikasi Android untuk mencoba potongan rambut pria secara live dengan AR,
dikembangkan dari konsep repo referensi
[crownyoung0303/Hairstyle-Simulation](https://github.com/crownyoung0303/hairstyle-simulation).

## Cara menjalankan

1. Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync.
2. Sambungkan HP Android 10 ke atas (emulator tidak bisa memakai kamera depan dengan baik).
3. Run. Saat build pertama, model `face_landmarker.task` diunduh otomatis ke `app/src/main/assets/`.
   Jika jaringan kantor memblokir, unduh manual dari
   `https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task`
   lalu taruh di folder tersebut.

### Tanpa Android Studio: build APK di GitHub

1. Buat repo GitHub baru (boleh private), push isi folder ini ke branch `main`.
2. Buka tab **Actions**, workflow **Build APK** berjalan otomatis (sekitar 5 sampai 10 menit).
3. Setelah hijau, buka run tersebut, unduh artifact `hair-tryon-debug-apk`, ekstrak, dan install `app-debug.apk` ke HP
   (izinkan "Install dari sumber tidak dikenal").

## Cara kerja

```mermaid
flowchart LR
    A[CameraX<br/>kamera depan] --> B[Preview<br/>SurfaceView]
    A --> C[ImageAnalysis<br/>640x480, dicerminkan]
    C --> D[MediaPipe Face Landmarker<br/>478 titik + matriks pose]
    D --> E[HairRenderer<br/>OpenGL ES]
    E --> F[Layer rambut transparan<br/>di atas preview]
    D --> G[FaceShapeClassifier<br/>rekomendasi]
    B & F --> H[Foto komposit<br/>galeri + bagikan]
```

1. **Pelacakan wajah**: MediaPipe memberi matriks pose kepala dalam satuan cm.
2. **Rambut**: mesh 3D prosedural berbentuk cangkang di atas elipsoid kepala, ditempel memakai matriks pose.
3. **Occlusion**: elipsoid kepala tak terlihat digambar lebih dulu (depth saja) agar rambut di belakang kepala tersembunyi.
4. **Shading**: highlight anisotropik mengikuti arah helai, variasi per helai, tepi garis rambut memudar.

## Pemetaan ke PRD

| Requirement | Status di prototype | Lokasi kode |
| --- | --- | --- |
| FR-01 Izin kamera dengan penjelasan | Ada | `MainActivity`, `permissionPanel` |
| FR-02 Panduan posisi wajah | Ada: wajah tidak terdeteksi, terlalu jauh, menoleh | `MainActivity.onFace` |
| FR-03 Rambut 3D live mengikuti kepala | Ada | `render/HairRenderer` |
| FR-04 Ganti gaya tanpa keluar sesi | Ada, 7 gaya | `hair/HairCatalog` |
| FR-05 Ganti warna | Ada, 6 warna | `hair/HairCatalog.colors` |
| FR-06 Bandingkan dua gaya | Belum | |
| FR-07 Telusuri per kategori | Ada: Pendek, Sedang, Tren | `setupCategories` |
| FR-08 Istilah untuk barber | Ada di bawah nama gaya | `HairStyle.barberTerm` |
| FR-09 Rekomendasi bentuk wajah | Ada, aturan awal | `face/FaceShapeClassifier` |
| FR-10 Foto, simpan, bagikan | Ada | `capture/PhotoSaver` |
| FR-11 Favorit | Belum | |
| FR-12 CMS konten | Belum, katalog masih di kode | |
| NFR-05 Proses di perangkat | Ada, tidak ada akses internet saat runtime | |

## Perbedaan dengan repo referensi

| Bagian | Referensi (2018) | Prototype ini | Alasan |
| --- | --- | --- | --- |
| Deteksi wajah | SDK SenseTime (tertutup, butuh lisensi) | MediaPipe (gratis, Apache 2.0) | SDK lama tidak bisa diperpanjang dan hanya 32-bit |
| 3D engine | Rajawali (tidak dirawat) | OpenGL ES langsung | Lebih sedikit dependency |
| Model rambut | File .obj tanpa lisensi | Mesh prosedural | Aman dipakai, mudah ditambah gaya |
| Build | Gradle 3.3, jcenter, 32-bit | Gradle 8.7, AndroidX, arm64 | Bisa di-build dan masuk Play Store |
| Rekomendasi | Ambang di README terbalik secara geometri | Arah dibetulkan, ambang perlu dikalibrasi | Lihat komentar di `FaceShapeClassifier` |

## Batasan yang perlu diketahui

- **Rambut asli tidak dihapus.** Gaya yang lebih pendek dari rambut asli tetap memperlihatkan rambut asli di tepinya.
- **Kepala didekati elipsoid.** Bentuk kepala yang berbeda diatasi lewat tombol Kalibrasi (geser naik/turun, maju/mundur, ukuran).
- **Rambut sedikit tertinggal** dari gerakan kepala cepat, karena preview dan deteksi berjalan terpisah.
- **Rambut prosedural terlihat seperti cangkang halus**, belum serealistis aset buatan 3D artist.
- **Ambang rekomendasi** (`P1_*`, `P2_*`) masih angka referensi dan perlu dikalibrasi dengan sampel wajah nyata.

## Jika posisi rambut kacau

- Rambut terbalik atau melayang jauh: cek apakah matriks MediaPipe dianggap column-major (`FaceFrame.pose`).
  Semua perhitungan di sini mengikuti asumsi itu.
- Rambut tergeser konsisten: atur dulu lewat Kalibrasi, lalu pindahkan nilai rata-ratanya ke `HeadModel`.
- Ukuran rambut tidak pas di HP tertentu: kamera virtual MediaPipe memakai FOV 63 derajat; kamera HP yang sangat lebar bisa sedikit meleset.

## Langkah berikutnya yang disarankan

1. Uji di 3 sampai 5 HP berbeda, catat FPS dan nilai kalibrasi rata-rata.
2. Uji ke 10 sampai 20 pengguna: apakah hasilnya cukup meyakinkan (gerbang fase prototype di PRD).
3. Ganti 2 sampai 3 gaya prosedural dengan aset 3D artist untuk membandingkan realisme.
4. Kalibrasi ambang rekomendasi bersama barber.
