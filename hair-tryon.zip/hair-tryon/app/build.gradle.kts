import java.io.InputStream
import java.net.URI

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "io.leniot.hairtryon"
    compileSdk = 34

    defaultConfig {
        applicationId = "io.leniot.hairtryon"
        // Android 10+: simpan foto ke galeri lewat MediaStore tanpa izin storage.
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-prototype"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }

    androidResources {
        // File model MediaPipe dibaca langsung dari assets, jangan dikompres.
        noCompress += "task"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    val cameraX = "1.3.4"
    implementation("androidx.camera:camera-core:$cameraX")
    implementation("androidx.camera:camera-camera2:$cameraX")
    implementation("androidx.camera:camera-lifecycle:$cameraX")
    implementation("androidx.camera:camera-view:$cameraX")

    // Deteksi 478 titik wajah + matriks pose kepala, jalan di perangkat (gratis, Apache 2.0).
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// Unduh model Face Landmarker sekali sebelum build (tidak disimpan di git).
val faceModelUrl =
    "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"

val downloadFaceModel by tasks.registering {
    val dest = file("src/main/assets/face_landmarker.task")
    outputs.file(dest)
    doLast {
        if (!dest.exists() || dest.length() == 0L) {
            dest.parentFile.mkdirs()
            logger.lifecycle("Mengunduh model MediaPipe ke ${dest.path}")
            URI(faceModelUrl).toURL().openStream().use { input: InputStream ->
                dest.outputStream().use { output -> input.copyTo(output) }
            }
        }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(downloadFaceModel)
}
