package io.leniot.hairtryon.hair

import io.leniot.hairtryon.face.FaceLength
import io.leniot.hairtryon.face.FaceShape
import io.leniot.hairtryon.face.FaceShapeResult

/**
 * Katalog gaya untuk prototype. Di produk, ini dimuat dari server (FR-12).
 */
object HairCatalog {

    val styles: List<HairStyle> = listOf(
        HairStyle(
            id = "buzz",
            name = "Buzz Cut",
            category = HairCategory.SHORT,
            description = "Cukur rata pendek di seluruh kepala. Praktis, rapi, minim perawatan.",
            barberTerm = "Clipper no. 2 rata semua",
            frontLine = 6.6f, sideLine = 2.0f, napeLine = -5.5f,
            topThickness = 0.25f, sideThickness = 0.2f, backThickness = 0.2f,
            topAlpha = 0.82f, sideAlpha = 0.7f,
        ),
        HairStyle(
            id = "crew",
            name = "Crew Cut",
            category = HairCategory.SHORT,
            description = "Atas pendek sedikit lebih panjang dari samping. Klasik dan aman untuk kantor.",
            barberTerm = "Atas gunting 2 sampai 3 cm, samping clipper no. 2 fade",
            frontLine = 6.6f, sideLine = 1.8f, napeLine = -5.8f,
            topThickness = 1.1f, sideThickness = 0.35f, backThickness = 0.45f,
            topStart = 0.45f, topEnd = 0.8f,
            sideAlpha = 0.85f,
        ),
        HairStyle(
            id = "side-part",
            name = "Side Part",
            category = HairCategory.SHORT,
            description = "Belah samping dengan panjang sedang di atas. Formal dan cocok untuk hampir semua wajah.",
            barberTerm = "Atas 5 sampai 6 cm, samping gunting tipis, belah kiri",
            frontLine = 6.4f, sideLine = 1.0f, napeLine = -6.5f,
            topThickness = 1.6f, sideThickness = 0.8f, backThickness = 0.9f,
            partU = 0.57f,
        ),
        HairStyle(
            id = "undercut",
            name = "Undercut",
            category = HairCategory.TREND,
            description = "Samping dan belakang dicukur sangat pendek, atas panjang disisir ke belakang.",
            barberTerm = "Samping dan belakang clipper no. 1 tanpa gradasi, atas 7 sampai 10 cm",
            frontLine = 6.6f, sideLine = 1.8f, napeLine = -5.5f,
            topThickness = 2.4f, sideThickness = 0.12f, backThickness = 0.15f,
            topStart = 0.55f, topEnd = 0.62f,
            sideAlpha = 0.55f,
        ),
        HairStyle(
            id = "pompadour",
            name = "Pompadour",
            category = HairCategory.TREND,
            description = "Volume tinggi di depan, samping pendek. Memberi kesan wajah lebih panjang.",
            barberTerm = "Atas 8 sampai 12 cm, samping skin fade, styling ke atas belakang",
            frontLine = 6.6f, sideLine = 1.8f, napeLine = -6.0f,
            topThickness = 2.2f, sideThickness = 0.3f, backThickness = 0.6f,
            topStart = 0.45f, topEnd = 0.7f,
            frontLift = 2.6f,
            sideAlpha = 0.85f,
        ),
        HairStyle(
            id = "two-block",
            name = "Two Block",
            category = HairCategory.TREND,
            description = "Gaya Korea: atas panjang dengan poni menutup dahi, samping bawah pendek.",
            barberTerm = "Samping bawah clipper no. 3, atas 8 cm dibiarkan jatuh dengan poni",
            frontLine = 4.6f, sideLine = 1.5f, napeLine = -6.0f,
            topThickness = 2.0f, sideThickness = 0.6f, backThickness = 0.9f,
            topStart = 0.25f, topEnd = 0.6f,
        ),
        HairStyle(
            id = "medium",
            name = "Gondrong Sedang",
            category = HairCategory.MEDIUM,
            description = "Panjang sampai bawah telinga, jatuh alami. Butuh perawatan lebih.",
            barberTerm = "Rapikan ujung saja, layer tipis, panjang sebatas rahang",
            frontLine = 5.5f, sideLine = -4.5f, napeLine = -8.5f,
            topThickness = 1.8f, sideThickness = 1.6f, backThickness = 1.8f,
            topStart = 0.2f, topEnd = 0.6f,
            drape = 1f,
        ),
    )

    val colors: List<HairColor> = listOf(
        HairColor("Hitam", 0x1B1612),
        HairColor("Cokelat tua", 0x3B2618),
        HairColor("Cokelat", 0x6B4423),
        HairColor("Pirang gelap", 0xA07A4A),
        HairColor("Abu-abu", 0x8A8A8A),
        HairColor("Burgundy", 0x5A1F24),
    )

    fun byId(id: String): HairStyle? = styles.firstOrNull { it.id == id }

    /**
     * Rekomendasi gaya dari bentuk wajah (FR-09). Aturan awal dari panduan umum barber:
     * wajah bulat butuh tinggi di atas dan samping tipis, wajah kotak cocok potongan rapi,
     * wajah panjang dihindarkan dari volume tinggi. Perlu divalidasi dengan barber.
     */
    fun recommend(result: FaceShapeResult): List<HairStyle> {
        val ids = when (result.shape) {
            FaceShape.ROUND -> mutableListOf("pompadour", "undercut", "side-part")
            FaceShape.SQUARE -> mutableListOf("crew", "buzz", "side-part")
            FaceShape.OVAL -> mutableListOf("side-part", "two-block", "medium")
        }
        when (result.length) {
            FaceLength.LONG -> {
                ids.remove("pompadour")
                ids.remove("two-block")
                ids.add(0, "two-block")
            }
            FaceLength.SHORT -> if ("pompadour" !in ids) ids.add(0, "pompadour")
            FaceLength.MEDIUM -> Unit
        }
        return ids.distinct().mapNotNull { byId(it) }
    }
}
