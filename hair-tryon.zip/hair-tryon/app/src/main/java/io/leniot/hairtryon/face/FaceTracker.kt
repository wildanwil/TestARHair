package io.leniot.hairtryon.face

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult

/**
 * Membungkus MediaPipe Face Landmarker dalam mode live stream.
 *
 * Pengganti SDK SenseTime di repo referensi: gratis, tanpa lisensi, mendukung arm64,
 * dan langsung memberi matriks pose kepala untuk menempelkan model 3D.
 *
 * Gambar kamera depan dicerminkan sebelum dideteksi supaya hasilnya cocok dengan
 * preview yang juga tampil tercermin. Dengan begitu renderer tidak perlu membalik apa pun.
 */
class FaceTracker(
    context: Context,
    private val onResult: (FaceFrame?) -> Unit,
) {
    private val landmarker: FaceLandmarker = create(context)
    private var lastTimestamp = 0L
    private var smoothedPose: FloatArray? = null

    private fun create(context: Context): FaceLandmarker = try {
        build(context, Delegate.GPU)
    } catch (e: Exception) {
        Log.w(TAG, "GPU delegate tidak tersedia, pakai CPU", e)
        build(context, Delegate.CPU)
    }

    private fun build(context: Context, delegate: Delegate): FaceLandmarker {
        val base = BaseOptions.builder()
            .setModelAssetPath(MODEL_ASSET)
            .setDelegate(delegate)
            .build()
        val options = FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumFaces(1)
            .setMinFaceDetectionConfidence(0.5f)
            .setMinFacePresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setOutputFacialTransformationMatrixes(true)
            .setResultListener { result, image -> handleResult(result, image.width, image.height) }
            .setErrorListener { e -> Log.e(TAG, "Face landmarker error", e) }
            .build()
        return FaceLandmarker.createFromOptions(context, options)
    }

    /** Dipanggil dari thread ImageAnalysis. Selalu menutup [image]. */
    fun detect(image: ImageProxy) {
        val frame: Bitmap
        try {
            val raw = image.toBitmap()
            val matrix = Matrix().apply {
                postRotate(image.imageInfo.rotationDegrees.toFloat())
                postScale(-1f, 1f) // cermin, sama seperti preview kamera depan
            }
            frame = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, false)
        } finally {
            image.close()
        }

        // MediaPipe mewajibkan timestamp yang terus naik.
        var ts = SystemClock.uptimeMillis()
        if (ts <= lastTimestamp) ts = lastTimestamp + 1
        lastTimestamp = ts

        landmarker.detectAsync(BitmapImageBuilder(frame).build(), ts)
    }

    private fun handleResult(result: FaceLandmarkerResult, width: Int, height: Int) {
        val faces = result.faceLandmarks()
        val matrices = result.facialTransformationMatrixes()
        if (faces.isEmpty() || !matrices.isPresent || matrices.get().isEmpty()) {
            smoothedPose = null
            onResult(null)
            return
        }

        val pose = smooth(matrices.get()[0])
        val landmarks = faces[0]
        val points = FloatArray(landmarks.size * 2)
        landmarks.forEachIndexed { i, lm ->
            points[i * 2] = lm.x() * width
            points[i * 2 + 1] = lm.y() * height
        }
        onResult(FaceFrame(pose, points, width, height, SystemClock.uptimeMillis()))
    }

    /** Peredam getaran sederhana: rata-rata bergerak per elemen matriks. */
    private fun smooth(raw: FloatArray): FloatArray {
        val prev = smoothedPose
        val out = if (prev == null) raw.copyOf() else FloatArray(16) { i ->
            prev[i] + (raw[i] - prev[i]) * SMOOTHING
        }
        smoothedPose = out
        return out.copyOf()
    }

    fun close() = landmarker.close()

    companion object {
        private const val TAG = "FaceTracker"
        const val MODEL_ASSET = "face_landmarker.task"

        /** 1 = tanpa peredam (paling responsif), makin kecil makin halus tapi makin telat. */
        private const val SMOOTHING = 0.65f
    }
}
