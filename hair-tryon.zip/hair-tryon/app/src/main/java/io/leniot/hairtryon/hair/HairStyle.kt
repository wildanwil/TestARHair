package io.leniot.hairtryon.hair

enum class HairCategory(val label: String) {
    SHORT("Pendek"),
    MEDIUM("Sedang"),
    TREND("Tren"),
}

/**
 * Definisi satu gaya rambut sebagai parameter mesh prosedural.
 *
 * Semua ukuran dalam cm di ruang canonical face MediaPipe (y ke atas, z ke arah kamera).
 * Garis rambut diukur sebagai ketinggian y di permukaan kepala.
 *
 * Gaya dibuat prosedural (bukan file .obj) karena model 3D di repo referensi tidak
 * berlisensi. Untuk produk, parameter ini bisa diganti aset 3D buatan artist.
 */
data class HairStyle(
    val id: String,
    val name: String,
    val category: HairCategory,
    val description: String,
    /** Istilah yang bisa langsung disebut ke barber (FR-08). */
    val barberTerm: String,

    /** Ketinggian garis rambut depan (dahi). Lebih rendah = ada poni. */
    val frontLine: Float,
    /** Ketinggian garis rambut di samping (di atas telinga). Negatif = menutup telinga. */
    val sideLine: Float,
    /** Ketinggian garis rambut belakang (tengkuk). */
    val napeLine: Float,

    /** Tebal rambut di bagian atas, samping, dan belakang. */
    val topThickness: Float,
    val sideThickness: Float,
    val backThickness: Float,

    /** Batas peralihan samping ke atas, dalam cos(sudut dari ubun-ubun). Rapat = potongan tegas. */
    val topStart: Float = 0.35f,
    val topEnd: Float = 0.8f,

    /** Tambahan volume di depan atas (pompadour/quiff). */
    val frontLift: Float = 0f,
    /** 0 = mengikuti bentuk kepala, 1 = jatuh lurus ke bawah (rambut panjang). */
    val drape: Float = 0f,

    /** Opasitas. Di bawah 1 terlihat seperti rambut sangat tipis/cukur. */
    val topAlpha: Float = 1f,
    val sideAlpha: Float = 1f,

    /** Posisi garis belahan pada koordinat u (0.5 = tengah depan). Negatif = tanpa belahan. */
    val partU: Float = -1f,
)

class HairColor(val name: String, hex: Long) {
    val rgb: FloatArray = floatArrayOf(
        ((hex shr 16) and 0xFF) / 255f,
        ((hex shr 8) and 0xFF) / 255f,
        (hex and 0xFF) / 255f,
    )
    val argb: Int = (0xFF000000 or hex).toInt()
}
