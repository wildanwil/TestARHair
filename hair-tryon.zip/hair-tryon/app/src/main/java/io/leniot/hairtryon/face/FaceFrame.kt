package io.leniot.hairtryon.face

import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * Satu hasil deteksi wajah.
 *
 * @param pose matriks 4x4 column-major dari MediaPipe: memetakan ruang "canonical face"
 *   (satuan cm, y ke atas, z ke arah kamera) ke ruang kamera OpenGL.
 * @param points koordinat 478 landmark dalam piksel gambar, berurutan x0, y0, x1, y1, ...
 * @param imageWidth lebar gambar yang dianalisis (sudah diputar dan dicerminkan).
 * @param imageHeight tinggi gambar yang dianalisis.
 * @param timestampMs waktu hasil diterima (SystemClock.uptimeMillis).
 */
class FaceFrame(
    val pose: FloatArray,
    val points: FloatArray,
    val imageWidth: Int,
    val imageHeight: Int,
    val timestampMs: Long,
) {
    /** Jarak kepala ke kamera dalam cm. */
    val distanceCm: Float
        get() {
            val x = pose[12]
            val y = pose[13]
            val z = pose[14]
            return sqrt(x * x + y * y + z * z)
        }

    /** Sudut menoleh kiri/kanan dalam derajat, 0 = menghadap kamera. */
    val yawDegrees: Float
        get() = Math.toDegrees(atan2(pose[8].toDouble(), pose[10].toDouble())).toFloat()
}
