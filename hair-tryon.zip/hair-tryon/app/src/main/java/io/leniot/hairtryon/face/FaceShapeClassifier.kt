package io.leniot.hairtryon.face

import kotlin.math.hypot

enum class FaceShape(val label: String) { OVAL("oval"), ROUND("bulat"), SQUARE("kotak") }

enum class FaceLength(val label: String) { SHORT("pendek"), MEDIUM("sedang"), LONG("panjang") }

data class FaceShapeResult(val shape: FaceShape, val length: FaceLength, val p1: Float, val p2: Float)

/**
 * Port algoritma rekomendasi dari repo referensi (Hairstyle-Simulation, EC601).
 *
 * Referensi memakai 68 titik wajah:
 *   p1 = jarak(1,15) / jarak(6,10)   lebar pipi dibanding lebar rahang bawah
 *   p2 = jarak(0,16) / jarak(8,27)   lebar wajah dibanding tinggi dagu ke pangkal hidung
 *
 * Di sini dipetakan ke indeks MediaPipe (478 titik):
 *   0 -> 234, 16 -> 454, 1 -> 93, 15 -> 323, 6 -> 149, 10 -> 378, 8 -> 152, 27 -> 168
 *
 * Catatan: arah ambang di README referensi terbalik secara geometri
 * (p1 kecil berarti rahang lebar, yaitu wajah kotak; p2 besar berarti wajah lebar dan pendek).
 * Di sini arahnya sudah dibetulkan. Angka ambang masih bawaan referensi dan WAJIB
 * dikalibrasi ulang dengan sampel wajah nyata, karena titik MediaPipe tidak persis sama.
 *
 * Pengambilan sampel dilakukan beberapa frame lalu diambil median agar stabil.
 */
class FaceShapeClassifier {
    private val p1Samples = ArrayList<Float>()
    private val p2Samples = ArrayList<Float>()

    val sampleCount: Int
        @Synchronized get() = p1Samples.size

    @Synchronized
    fun reset() {
        p1Samples.clear()
        p2Samples.clear()
    }

    @Synchronized
    fun add(points: FloatArray) {
        if (points.size < 478 * 2) return
        val jawLower = dist(points, 149, 378)
        val faceLength = dist(points, 152, 168)
        if (jawLower < 1f || faceLength < 1f) return
        p1Samples += dist(points, 93, 323) / jawLower
        p2Samples += dist(points, 234, 454) / faceLength
    }

    @Synchronized
    fun result(): FaceShapeResult? {
        if (p1Samples.isEmpty()) return null
        val p1 = median(p1Samples)
        val p2 = median(p2Samples)
        val shape = when {
            p1 < P1_SQUARE_MAX -> FaceShape.SQUARE
            p1 < P1_ROUND_MAX -> FaceShape.ROUND
            else -> FaceShape.OVAL
        }
        val length = when {
            p2 < P2_LONG_MAX -> FaceLength.LONG
            p2 < P2_MEDIUM_MAX -> FaceLength.MEDIUM
            else -> FaceLength.SHORT
        }
        return FaceShapeResult(shape, length, p1, p2)
    }

    private fun dist(p: FloatArray, a: Int, b: Int): Float =
        hypot(p[a * 2] - p[b * 2], p[a * 2 + 1] - p[b * 2 + 1])

    private fun median(values: List<Float>): Float {
        val sorted = values.sorted()
        return sorted[sorted.size / 2]
    }

    companion object {
        // Ambang bawaan referensi. Kalibrasi ulang sebelum dipakai di produksi.
        const val P1_SQUARE_MAX = 2.0f
        const val P1_ROUND_MAX = 2.5f
        const val P2_LONG_MAX = 1.0f
        const val P2_MEDIUM_MAX = 1.15f
    }
}
