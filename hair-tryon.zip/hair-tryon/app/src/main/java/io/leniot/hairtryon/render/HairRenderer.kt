package io.leniot.hairtryon.render

import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.SystemClock
import io.leniot.hairtryon.face.FaceFrame
import io.leniot.hairtryon.hair.HairCatalog
import io.leniot.hairtryon.hair.HairMeshBuilder
import io.leniot.hairtryon.hair.HairStyle
import io.leniot.hairtryon.hair.HeadModel
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicReference
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import android.graphics.Matrix as BitmapMatrix
import android.opengl.Matrix as GlMatrix

/**
 * Menggambar rambut 3D di atas preview kamera (GLSurfaceView transparan).
 *
 * Kamera virtual meniru kamera yang diasumsikan MediaPipe: perspektif dengan
 * FOV vertikal 63 derajat terhadap gambar yang dianalisis. Lalu diskalakan agar cocok
 * dengan cara PreviewView memotong gambar (FILL_CENTER).
 */
class HairRenderer : GLSurfaceView.Renderer {

    @Volatile var calibration = Calibration()
    @Volatile var hairColor: FloatArray = HairCatalog.colors.first().rgb
    @Volatile private var face: FaceFrame? = null

    private val pendingStyle = AtomicReference<HairStyle?>(HairCatalog.styles.first())
    private val snapshotRequest = AtomicReference<((Bitmap) -> Unit)?>(null)
    private var currentStyle: HairStyle? = null

    private lateinit var hairProgram: GlProgram
    private lateinit var depthProgram: GlProgram
    private var hairMesh: GpuMesh? = null
    private var headMesh: GpuMesh? = null

    private var width = 1
    private var height = 1

    private val proj = FloatArray(16)
    private val fit = FloatArray(16)
    private val projFit = FloatArray(16)
    private val model = FloatArray(16)
    private val modelView = FloatArray(16)
    private val mvp = FloatArray(16)
    private val normalMat = FloatArray(9)

    fun setStyle(style: HairStyle) = pendingStyle.set(style)

    fun updateFace(frame: FaceFrame?) {
        face = frame
    }

    /** Minta isi layer rambut sebagai bitmap. Callback dipanggil di thread GL. */
    fun requestSnapshot(callback: (Bitmap) -> Unit) = snapshotRequest.set(callback)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        hairProgram = GlProgram(Shaders.HAIR_VS, Shaders.HAIR_FS)
        depthProgram = GlProgram(Shaders.DEPTH_VS, Shaders.DEPTH_FS)
        headMesh = GpuMesh.upload(HairMeshBuilder.buildHeadOccluder())
        // Context GL baru: mesh lama ikut hilang, bangun ulang gaya yang sedang aktif.
        hairMesh = null
        currentStyle?.let { pendingStyle.compareAndSet(null, it) }
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = maxOf(w, 1)
        height = maxOf(h, 1)
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glDepthMask(true)
        GLES20.glColorMask(true, true, true, true)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        pendingStyle.getAndSet(null)?.let { style ->
            hairMesh?.release()
            hairMesh = GpuMesh.upload(HairMeshBuilder.buildHair(style))
            currentStyle = style
        }

        val f = face
        val mesh = hairMesh
        if (f != null && mesh != null && SystemClock.uptimeMillis() - f.timestampMs < STALE_MS) {
            drawHair(f, mesh)
        }

        snapshotRequest.getAndSet(null)?.invoke(readPixels())
    }

    private fun drawHair(f: FaceFrame, mesh: GpuMesh) {
        // Proyeksi kamera MediaPipe terhadap gambar yang dianalisis.
        val imageAspect = f.imageWidth.toFloat() / f.imageHeight
        val viewAspect = width.toFloat() / height
        GlMatrix.perspectiveM(proj, 0, MEDIAPIPE_VFOV_DEG, imageAspect, NEAR, FAR)

        // FILL_CENTER: gambar diperbesar sampai menutupi view, sisi yang lebih memotong.
        GlMatrix.setIdentityM(fit, 0)
        if (viewAspect > imageAspect) {
            GlMatrix.scaleM(fit, 0, 1f, viewAspect / imageAspect, 1f)
        } else {
            GlMatrix.scaleM(fit, 0, imageAspect / viewAspect, 1f, 1f)
        }
        GlMatrix.multiplyMM(projFit, 0, fit, 0, proj, 0)

        // Kalibrasi: geser lalu skala di sekitar pusat kepala.
        val c = calibration
        GlMatrix.setIdentityM(model, 0)
        GlMatrix.translateM(model, 0, 0f, c.offsetY, c.offsetZ)
        GlMatrix.translateM(model, 0, HeadModel.CX, HeadModel.CY, HeadModel.CZ)
        GlMatrix.scaleM(model, 0, c.scale, c.scale, c.scale)
        GlMatrix.translateM(model, 0, -HeadModel.CX, -HeadModel.CY, -HeadModel.CZ)

        GlMatrix.multiplyMM(modelView, 0, f.pose, 0, model, 0)
        GlMatrix.multiplyMM(mvp, 0, projFit, 0, modelView, 0)

        // Rotasi dari modelView (skala seragam, jadi cukup dinormalisasi di shader).
        normalMat[0] = modelView[0]; normalMat[1] = modelView[1]; normalMat[2] = modelView[2]
        normalMat[3] = modelView[4]; normalMat[4] = modelView[5]; normalMat[5] = modelView[6]
        normalMat[6] = modelView[8]; normalMat[7] = modelView[9]; normalMat[8] = modelView[10]

        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glDisable(GLES20.GL_CULL_FACE)

        // Pass 1: kepala, depth saja.
        GLES20.glColorMask(false, false, false, false)
        GLES20.glUseProgram(depthProgram.id)
        GLES20.glUniformMatrix4fv(depthProgram.uniform("uMvp"), 1, false, mvp, 0)
        headMesh?.draw(depthProgram)

        // Pass 2: rambut dengan blending premultiplied alpha.
        GLES20.glColorMask(true, true, true, true)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUseProgram(hairProgram.id)
        GLES20.glUniformMatrix4fv(hairProgram.uniform("uMvp"), 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(hairProgram.uniform("uModelView"), 1, false, modelView, 0)
        GLES20.glUniformMatrix3fv(hairProgram.uniform("uNormalMat"), 1, false, normalMat, 0)
        val color = hairColor
        GLES20.glUniform3f(hairProgram.uniform("uColor"), color[0], color[1], color[2])
        GLES20.glUniform1f(hairProgram.uniform("uPartU"), currentStyle?.partU ?: -1f)
        mesh.draw(hairProgram)

        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
    }

    private fun readPixels(): Bitmap {
        val buffer = ByteBuffer.allocateDirect(width * height * 4).order(ByteOrder.nativeOrder())
        GLES20.glReadPixels(0, 0, width, height, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buffer)
        buffer.rewind()
        val raw = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(buffer)
        // OpenGL membaca dari bawah ke atas, balik secara vertikal.
        val flip = BitmapMatrix().apply { preScale(1f, -1f) }
        return Bitmap.createBitmap(raw, 0, 0, width, height, flip, false)
    }

    companion object {
        /** Nilai bawaan kamera virtual MediaPipe Face Geometry. */
        private const val MEDIAPIPE_VFOV_DEG = 63f
        private const val NEAR = 1f
        private const val FAR = 10000f

        /** Sembunyikan rambut jika hasil deteksi terakhir lebih tua dari ini. */
        private const val STALE_MS = 400L
    }
}
