package io.leniot.hairtryon.render

/** Shader GLSL ES 1.00. */
object Shaders {

    /** Pass 1: kepala tak terlihat yang hanya menulis depth, supaya rambut di belakang kepala tersembunyi. */
    const val DEPTH_VS = """
        uniform mat4 uMvp;
        attribute vec3 aPos;
        void main() {
            gl_Position = uMvp * vec4(aPos, 1.0);
        }
    """

    const val DEPTH_FS = """
        precision mediump float;
        void main() {
            gl_FragColor = vec4(0.0);
        }
    """

    const val HAIR_VS = """
        uniform mat4 uMvp;
        uniform mat4 uModelView;
        uniform mat3 uNormalMat;
        attribute vec3 aPos;
        attribute vec3 aNormal;
        attribute vec3 aTangent;
        attribute vec2 aUv;
        attribute float aAlpha;
        varying vec3 vNormal;
        varying vec3 vTangent;
        varying vec3 vViewPos;
        varying vec2 vUv;
        varying float vAlpha;
        void main() {
            vViewPos = (uModelView * vec4(aPos, 1.0)).xyz;
            vNormal = uNormalMat * aNormal;
            vTangent = uNormalMat * aTangent;
            vUv = aUv;
            vAlpha = aAlpha;
            gl_Position = uMvp * vec4(aPos, 1.0);
        }
    """

    /**
     * Shading rambut: diffuse + highlight anisotropik Kajiya-Kay mengikuti arah helai,
     * variasi terang-gelap per helai, garis belahan opsional.
     * Output premultiplied alpha karena surface Android memakai premultiplied.
     */
    const val HAIR_FS = """
        #ifdef GL_FRAGMENT_PRECISION_HIGH
        precision highp float;
        #else
        precision mediump float;
        #endif
        uniform vec3 uColor;
        uniform float uPartU;
        varying vec3 vNormal;
        varying vec3 vTangent;
        varying vec3 vViewPos;
        varying vec2 vUv;
        varying float vAlpha;

        float hash(float n) { return fract(sin(n) * 43758.5453); }

        void main() {
            vec3 N = normalize(vNormal);
            vec3 T = normalize(vTangent);
            vec3 V = normalize(-vViewPos);
            if (dot(N, V) < 0.0) N = -N;
            vec3 L = normalize(vec3(0.3, 0.8, 0.6));

            float diffuse = 0.35 + 0.65 * max(dot(N, L), 0.0);
            vec3 H = normalize(L + V);
            float th = dot(T, H);
            float spec = pow(sqrt(max(1.0 - th * th, 0.0)), 60.0);

            float strand = 0.8 + 0.35 * hash(floor(vUv.x * 900.0));
            float fine = 0.9 + 0.1 * hash(floor(vUv.x * 2600.0) + floor(vUv.y * 8.0) * 13.0);
            vec3 col = uColor * diffuse * strand * fine + vec3(0.18) * spec * strand;

            if (uPartU > 0.0) {
                float du = vUv.x - uPartU;
                float part = exp(-du * du / 0.00002) * smoothstep(0.15, 0.3, vUv.y);
                col *= 1.0 - 0.45 * part;
            }

            float rim = pow(1.0 - max(dot(N, V), 0.0), 3.0);
            float a = clamp(vAlpha * (1.0 - 0.35 * rim), 0.0, 1.0);
            gl_FragColor = vec4(col * a, a);
        }
    """
}
