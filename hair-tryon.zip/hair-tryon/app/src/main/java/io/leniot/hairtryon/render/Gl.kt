package io.leniot.hairtryon.render

import android.opengl.GLES20
import io.leniot.hairtryon.hair.MeshData
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Program shader OpenGL ES 2.0 dengan cache lokasi attribute dan uniform. */
class GlProgram(vertexSrc: String, fragmentSrc: String) {
    val id: Int
    private val attribs = HashMap<String, Int>()
    private val uniforms = HashMap<String, Int>()

    init {
        val vs = compile(GLES20.GL_VERTEX_SHADER, vertexSrc)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, fragmentSrc)
        id = GLES20.glCreateProgram()
        GLES20.glAttachShader(id, vs)
        GLES20.glAttachShader(id, fs)
        GLES20.glLinkProgram(id)
        val status = IntArray(1)
        GLES20.glGetProgramiv(id, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetProgramInfoLog(id)
            GLES20.glDeleteProgram(id)
            throw IllegalStateException("Link shader gagal: $log")
        }
        GLES20.glDeleteShader(vs)
        GLES20.glDeleteShader(fs)
    }

    fun attrib(name: String): Int = attribs.getOrPut(name) { GLES20.glGetAttribLocation(id, name) }

    fun uniform(name: String): Int = uniforms.getOrPut(name) { GLES20.glGetUniformLocation(id, name) }

    private fun compile(type: Int, src: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, src)
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(shader)
            GLES20.glDeleteShader(shader)
            throw IllegalStateException("Compile shader gagal: $log")
        }
        return shader
    }
}

/** Mesh di GPU (VBO + IBO) dengan layout [MeshData]. */
class GpuMesh private constructor(
    private val vbo: Int,
    private val ibo: Int,
    private val indexCount: Int,
) {
    fun draw(program: GlProgram) {
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ibo)
        val stride = MeshData.STRIDE_FLOATS * 4
        val enabled = ArrayList<Int>(5)
        fun bind(name: String, size: Int, offsetFloats: Int) {
            val loc = program.attrib(name)
            if (loc < 0) return
            GLES20.glEnableVertexAttribArray(loc)
            GLES20.glVertexAttribPointer(loc, size, GLES20.GL_FLOAT, false, stride, offsetFloats * 4)
            enabled += loc
        }
        bind("aPos", 3, 0)
        bind("aNormal", 3, 3)
        bind("aTangent", 3, 6)
        bind("aUv", 2, 9)
        bind("aAlpha", 1, 11)

        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_SHORT, 0)

        enabled.forEach { GLES20.glDisableVertexAttribArray(it) }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    fun release() {
        GLES20.glDeleteBuffers(2, intArrayOf(vbo, ibo), 0)
    }

    companion object {
        fun upload(data: MeshData): GpuMesh {
            val ids = IntArray(2)
            GLES20.glGenBuffers(2, ids, 0)

            val vb = ByteBuffer.allocateDirect(data.vertices.size * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer()
            vb.put(data.vertices).position(0)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, data.vertices.size * 4, vb, GLES20.GL_STATIC_DRAW)

            val ib = ByteBuffer.allocateDirect(data.indices.size * 2)
                .order(ByteOrder.nativeOrder()).asShortBuffer()
            ib.put(data.indices).position(0)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, ids[1])
            GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, data.indices.size * 2, ib, GLES20.GL_STATIC_DRAW)

            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
            return GpuMesh(ids[0], ids[1], data.indices.size)
        }
    }
}
