package io.leniot.hairtryon.render

import android.content.Context

/**
 * Penyesuaian posisi rambut terhadap kepala, dalam cm dan faktor skala.
 * Bentuk kepala tiap orang berbeda dari elipsoid standar, jadi pengguna bisa menggeser sedikit.
 */
data class Calibration(
    val offsetY: Float = 0f,
    val offsetZ: Float = 0f,
    val scale: Float = 1f,
) {
    fun save(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putFloat(KEY_Y, offsetY)
            .putFloat(KEY_Z, offsetZ)
            .putFloat(KEY_SCALE, scale)
            .apply()
    }

    companion object {
        private const val PREFS = "calibration"
        private const val KEY_Y = "offset_y"
        private const val KEY_Z = "offset_z"
        private const val KEY_SCALE = "scale"

        const val OFFSET_RANGE_CM = 4f
        const val SCALE_MIN = 0.85f
        const val SCALE_MAX = 1.15f

        fun load(context: Context): Calibration {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return Calibration(
                p.getFloat(KEY_Y, 0f),
                p.getFloat(KEY_Z, 0f),
                p.getFloat(KEY_SCALE, 1f),
            )
        }
    }
}
