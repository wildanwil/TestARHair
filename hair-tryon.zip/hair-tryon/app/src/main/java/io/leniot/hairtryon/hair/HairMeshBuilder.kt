package io.leniot.hairtryon.hair

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Data mesh siap diunggah ke GPU. Layout per vertex: lihat [MeshData.STRIDE_FLOATS]. */
class MeshData(val vertices: FloatArray, val indices: ShortArray) {
    companion object {
        /** posisi(3) normal(3) tangent(3) uv(2) alpha(1) */
        const val STRIDE_FLOATS = 12
    }
}

/**
 * Perkiraan kepala dalam ruang canonical face MediaPipe (cm).
 * Wajah canonical: ujung hidung sekitar (0, -1.1, 7.5), dahi sekitar y 6.5, dagu sekitar y -8.
 * Kepala didekati elipsoid. Selisih kepala tiap orang ditangani lewat kalibrasi di aplikasi.
 */
object HeadModel {
    const val CX = 0f
    const val CY = 2.5f
    // Sedikit ke depan supaya garis rambut depan duduk di atas dahi, bukan di belakangnya.
    const val CZ = -4.0f
    const val RX = 7.8f
    const val RY = 11.5f
    const val RZ = 10.2f
}

/**
 * Membangun mesh rambut prosedural berbentuk cangkang di atas elipsoid kepala.
 *
 * Parameterisasi: theta = sudut keliling (0 = depan), phi = sudut dari ubun-ubun.
 * Tiap kolom theta berjalan dari ubun-ubun (s = 0) sampai garis rambut (s = 1),
 * sehingga tepi rambut halus tanpa potongan segitiga bergerigi.
 */
object HairMeshBuilder {
    private const val COLS = 128
    private const val ROWS = 56

    fun buildHair(style: HairStyle): MeshData {
        val rowCount = ROWS + 1
        val colCount = COLS + 1 // kolom terakhir duplikat kolom pertama agar u tidak melompat
        val pos = Array(colCount) { Array(rowCount) { FloatArray(3) } }
        val alpha = Array(colCount) { FloatArray(rowCount) }

        for (i in 0 until colCount) {
            val u = i.toFloat() / COLS
            val theta = (-PI + 2 * PI * u).toFloat()
            val phiEnd = phiForHeight(hairlineAt(style, theta))
            for (j in 0 until rowCount) {
                val s = j.toFloat() / ROWS
                val phi = s * phiEnd
                val t = thickness(style, theta, phi, s)
                surfacePoint(theta, phi, t, style.drape, pos[i][j])
                alpha[i][j] = alphaAt(style, phi, s)
            }
        }

        val verts = FloatArray(colCount * rowCount * MeshData.STRIDE_FLOATS)
        val n = FloatArray(3)
        val tan = FloatArray(3)
        for (i in 0 until colCount) {
            // Tetangga keliling dengan wrap, abaikan kolom duplikat.
            val prevI = if (i == 0) COLS - 1 else i - 1
            val nextI = if (i >= COLS - 1) (i + 1) % COLS else i + 1
            for (j in 0 until rowCount) {
                val p = pos[i][j]
                val down = pos[i][minOf(j + 1, ROWS)]
                val up = pos[i][maxOf(j - 1, 0)]
                sub(down, up, tan)
                normalize(tan, fallbackY = -1f)

                val dTheta = FloatArray(3)
                sub(pos[nextI][j], pos[prevI][j], dTheta)
                cross(dTheta, tan, n)
                if (length(n) < 1e-5f) {
                    n[0] = 0f; n[1] = 1f; n[2] = 0f
                } else {
                    normalize(n)
                    // Pastikan normal menghadap keluar dari pusat kepala.
                    val ox = p[0] - HeadModel.CX
                    val oy = p[1] - HeadModel.CY
                    val oz = p[2] - HeadModel.CZ
                    if (n[0] * ox + n[1] * oy + n[2] * oz < 0f) {
                        n[0] = -n[0]; n[1] = -n[1]; n[2] = -n[2]
                    }
                }

                val o = (i * rowCount + j) * MeshData.STRIDE_FLOATS
                verts[o] = p[0]; verts[o + 1] = p[1]; verts[o + 2] = p[2]
                verts[o + 3] = n[0]; verts[o + 4] = n[1]; verts[o + 5] = n[2]
                verts[o + 6] = tan[0]; verts[o + 7] = tan[1]; verts[o + 8] = tan[2]
                verts[o + 9] = i.toFloat() / COLS
                verts[o + 10] = j.toFloat() / ROWS
                verts[o + 11] = alpha[i][j]
            }
        }

        val idx = ShortArray(COLS * ROWS * 6)
        var k = 0
        for (i in 0 until COLS) {
            for (j in 0 until ROWS) {
                val a = (i * rowCount + j).toShort()
                val b = ((i + 1) * rowCount + j).toShort()
                val c = (i * rowCount + j + 1).toShort()
                val d = ((i + 1) * rowCount + j + 1).toShort()
                idx[k++] = a; idx[k++] = c; idx[k++] = b
                idx[k++] = b; idx[k++] = c; idx[k++] = d
            }
        }
        return MeshData(verts, idx)
    }

    /** Elipsoid kepala yang sedikit lebih kecil, hanya untuk depth (menyembunyikan rambut di balik kepala). */
    fun buildHeadOccluder(): MeshData {
        val cols = 48
        val rows = 32
        val shrink = 0.96f
        val rowCount = rows + 1
        val verts = FloatArray((cols + 1) * rowCount * MeshData.STRIDE_FLOATS)
        for (i in 0..cols) {
            val theta = (2 * PI * i / cols).toFloat()
            for (j in 0..rows) {
                val phi = (PI * j / rows).toFloat()
                val o = (i * rowCount + j) * MeshData.STRIDE_FLOATS
                verts[o] = HeadModel.CX + HeadModel.RX * shrink * sin(phi) * sin(theta)
                verts[o + 1] = HeadModel.CY + HeadModel.RY * shrink * cos(phi)
                verts[o + 2] = HeadModel.CZ + HeadModel.RZ * shrink * sin(phi) * cos(theta)
            }
        }
        val idx = ShortArray(cols * rows * 6)
        var k = 0
        for (i in 0 until cols) {
            for (j in 0 until rows) {
                val a = (i * rowCount + j).toShort()
                val b = ((i + 1) * rowCount + j).toShort()
                val c = (i * rowCount + j + 1).toShort()
                val d = ((i + 1) * rowCount + j + 1).toShort()
                idx[k++] = a; idx[k++] = c; idx[k++] = b
                idx[k++] = b; idx[k++] = c; idx[k++] = d
            }
        }
        return MeshData(verts, idx)
    }

    /** Ketinggian garis rambut untuk sudut keliling theta: depan -> samping -> belakang. */
    private fun hairlineAt(style: HairStyle, theta: Float): Float {
        val w = abs(theta) / PI.toFloat() // 0 depan, 0.5 samping, 1 belakang
        return if (w < 0.5f) {
            lerp(style.frontLine, style.sideLine, smoothstep(0f, 0.5f, w))
        } else {
            lerp(style.sideLine, style.napeLine, smoothstep(0.5f, 1f, w))
        }
    }

    private fun phiForHeight(y: Float): Float =
        acos(((y - HeadModel.CY) / HeadModel.RY).coerceIn(-1f, 1f))

    private fun thickness(style: HairStyle, theta: Float, phi: Float, s: Float): Float {
        val cosT = cos(theta)
        val topW = smoothstep(style.topStart, style.topEnd, cos(phi))
        val sideBack = lerp(style.sideThickness, style.backThickness, smoothstep(0f, 1f, maxOf(-cosT, 0f)))
        var t = lerp(sideBack, style.topThickness, topW)

        if (style.frontLift > 0f) {
            val front = maxOf(cosT, 0f)
            t += style.frontLift * front * front * front * topW * smoothstep(0f, 0.6f, sin(phi))
        }
        // Menipis di dekat garis rambut agar tepinya menyatu dengan kulit.
        val edge = smoothstep(0.82f, 1f, s)
        return t * lerp(1f, 0.35f, edge)
    }

    private fun alphaAt(style: HairStyle, phi: Float, s: Float): Float {
        val topW = smoothstep(style.topStart, style.topEnd, cos(phi))
        val base = lerp(style.sideAlpha, style.topAlpha, topW)
        val edgeFade = 1f - smoothstep(0.9f, 1f, s) * 0.85f
        return base * edgeFade
    }

    private fun surfacePoint(theta: Float, phi: Float, t: Float, drape: Float, out: FloatArray) {
        val sinPhi = sin(phi)
        // Di bawah bagian terlebar kepala, rambut panjang jatuh lurus (silinder), tidak ikut melengkung ke dalam.
        val h = if (phi <= (PI / 2).toFloat()) sinPhi else lerp(sinPhi, 1f, drape)
        out[0] = HeadModel.CX + (HeadModel.RX + t) * h * sin(theta)
        out[1] = HeadModel.CY + (HeadModel.RY + t) * cos(phi)
        out[2] = HeadModel.CZ + (HeadModel.RZ + t) * h * cos(theta)
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private fun smoothstep(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun sub(a: FloatArray, b: FloatArray, out: FloatArray) {
        out[0] = a[0] - b[0]; out[1] = a[1] - b[1]; out[2] = a[2] - b[2]
    }

    private fun cross(a: FloatArray, b: FloatArray, out: FloatArray) {
        out[0] = a[1] * b[2] - a[2] * b[1]
        out[1] = a[2] * b[0] - a[0] * b[2]
        out[2] = a[0] * b[1] - a[1] * b[0]
    }

    private fun length(v: FloatArray) = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2])

    private fun normalize(v: FloatArray, fallbackY: Float = 1f) {
        val l = length(v)
        if (l < 1e-6f) {
            v[0] = 0f; v[1] = fallbackY; v[2] = 0f
        } else {
            v[0] /= l; v[1] /= l; v[2] /= l
        }
    }
}
