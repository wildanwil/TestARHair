package io.leniot.hairtryon

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.SystemClock
import android.util.Size
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import io.leniot.hairtryon.capture.PhotoSaver
import io.leniot.hairtryon.databinding.ActivityMainBinding
import io.leniot.hairtryon.face.FaceFrame
import io.leniot.hairtryon.face.FaceShapeClassifier
import io.leniot.hairtryon.face.FaceTracker
import io.leniot.hairtryon.hair.HairCatalog
import io.leniot.hairtryon.hair.HairCategory
import io.leniot.hairtryon.hair.HairColor
import io.leniot.hairtryon.hair.HairStyle
import io.leniot.hairtryon.render.Calibration
import io.leniot.hairtryon.render.HairRenderer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val renderer = HairRenderer()
    private val classifier = FaceShapeClassifier()

    private lateinit var analysisExecutor: ExecutorService
    private val ioExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var tracker: FaceTracker? = null
    @Volatile private var trackerFailed = false

    @Volatile private var lastFaceMs = 0L
    @Volatile private var sampling = false
    @Volatile private var lastStatus: String? = null

    private var currentStyle: HairStyle = HairCatalog.styles.first()
    private var currentColor: HairColor = HairCatalog.colors.first()
    private var currentCategory: HairCategory? = null
    private lateinit var calibration: Calibration

    private val requestCamera = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            binding.permissionPanel.visibility = View.GONE
            startCamera()
        } else {
            binding.permissionBody.setText(R.string.permission_denied)
            binding.permissionPanel.visibility = View.VISIBLE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        calibration = Calibration.load(this)
        renderer.calibration = calibration
        renderer.hairColor = currentColor.rgb

        binding.glView.apply {
            setEGLContextClientVersion(2)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
            holder.setFormat(PixelFormat.TRANSLUCENT)
            // Di atas SurfaceView preview kamera, tetap di bawah tombol-tombol UI.
            setZOrderMediaOverlay(true)
            preserveEGLContextOnPause = true
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        binding.previewView.implementationMode = PreviewView.ImplementationMode.PERFORMANCE
        binding.previewView.scaleType = PreviewView.ScaleType.FILL_CENTER

        setupCategories()
        renderStyleChips()
        setupColors()
        setupButtons()
        setupCalibration()
        selectStyle(currentStyle)

        analysisExecutor = Executors.newSingleThreadExecutor()
        analysisExecutor.execute {
            try {
                tracker = FaceTracker(this, ::onFace)
            } catch (e: Exception) {
                trackerFailed = true
                runOnUiThread {
                    binding.statusText.text = getString(R.string.model_error, e.message ?: e.javaClass.simpleName)
                }
            }
        }

        binding.btnPermission.setOnClickListener { requestCamera.launch(Manifest.permission.CAMERA) }
        if (hasCameraPermission()) {
            startCamera()
        } else {
            binding.permissionPanel.visibility = View.VISIBLE
        }
    }

    override fun onResume() {
        super.onResume()
        binding.glView.onResume()
    }

    override fun onPause() {
        binding.glView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        analysisExecutor.execute { tracker?.close() }
        analysisExecutor.shutdown()
        ioExecutor.shutdown()
    }

    private fun hasCameraPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    // ---------- Kamera ----------

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()

            // Preview dan analisis memakai rasio yang sama (4:3) agar posisi rambut cocok dengan gambar.
            val aspect = AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
            val preview = Preview.Builder()
                .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspect).build())
                .build()
                .also { it.setSurfaceProvider(binding.previewView.surfaceProvider) }

            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setAspectRatioStrategy(aspect)
                        .setResolutionStrategy(
                            ResolutionStrategy(
                                Size(640, 480),
                                ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER,
                            ),
                        )
                        .build(),
                )
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(analysisExecutor) { image ->
                val t = tracker
                if (t == null) image.close() else t.detect(image)
            }

            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    /** Dipanggil dari thread MediaPipe setiap frame. */
    private fun onFace(frame: FaceFrame?) {
        renderer.updateFace(frame)
        if (frame != null) lastFaceMs = SystemClock.uptimeMillis()

        if (sampling && frame != null) {
            classifier.add(frame.points)
            if (classifier.sampleCount >= RECOMMEND_SAMPLES) {
                sampling = false
                val result = classifier.result()
                runOnUiThread { showRecommendation(result) }
            }
        }

        // Panduan posisi wajah (FR-02). Hanya update UI saat teksnya berubah.
        val status = when {
            sampling -> getString(R.string.status_analyzing)
            frame == null -> getString(R.string.status_no_face)
            frame.distanceCm > MAX_DISTANCE_CM -> getString(R.string.status_too_far)
            abs(frame.yawDegrees) > MAX_YAW_DEG -> getString(R.string.status_turn)
            else -> null
        }
        if (status != lastStatus) {
            lastStatus = status
            runOnUiThread {
                if (trackerFailed) return@runOnUiThread
                binding.statusText.text = status
                binding.statusText.visibility = if (status == null) View.GONE else View.VISIBLE
            }
        }
    }

    // ---------- Katalog ----------

    private fun setupCategories() {
        val group = binding.categoryChips
        val options = listOf<HairCategory?>(null) + HairCategory.entries
        options.forEach { category ->
            val chip = Chip(this).apply {
                id = View.generateViewId()
                text = category?.label ?: getString(R.string.filter_all)
                isCheckable = true
                isChecked = category == null
                setOnClickListener {
                    currentCategory = category
                    renderStyleChips()
                }
            }
            group.addView(chip)
        }
    }

    private fun renderStyleChips() {
        val group = binding.styleChips
        group.removeAllViews()
        HairCatalog.styles
            .filter { currentCategory == null || it.category == currentCategory }
            .forEach { style ->
                val chip = Chip(this).apply {
                    id = View.generateViewId()
                    text = style.name
                    tag = style.id
                    isCheckable = true
                    isChecked = style.id == currentStyle.id
                    setOnClickListener { selectStyle(style) }
                }
                group.addView(chip)
            }
    }

    private fun selectStyle(style: HairStyle) {
        currentStyle = style
        renderer.setStyle(style)
        binding.styleInfo.text = "${style.name} · ${style.category.label}\n${style.barberTerm}"
        for (i in 0 until binding.styleChips.childCount) {
            val chip = binding.styleChips.getChildAt(i) as Chip
            chip.isChecked = chip.tag == style.id
        }
    }

    private fun setupColors() {
        val size = dp(36)
        val margin = dp(6)
        HairCatalog.colors.forEach { color ->
            val swatch = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(size, size).apply { setMargins(margin, margin, margin, margin) }
                contentDescription = color.name
                tag = color
                setOnClickListener { selectColor(color) }
            }
            binding.colorRow.addView(swatch)
        }
        selectColor(currentColor)
    }

    private fun selectColor(color: HairColor) {
        currentColor = color
        renderer.hairColor = color.rgb
        for (i in 0 until binding.colorRow.childCount) {
            val v = binding.colorRow.getChildAt(i)
            val c = v.tag as HairColor
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c.argb)
                setStroke(if (c === color) dp(3) else dp(1), if (c === color) 0xFFFFB74D.toInt() else 0x66FFFFFF)
            }
        }
    }

    // ---------- Tombol ----------

    private fun setupButtons() {
        binding.btnCapture.setOnClickListener { capture() }
        binding.btnRecommend.setOnClickListener { startRecommendation() }
        binding.btnCalibrate.setOnClickListener {
            binding.calibPanel.visibility =
                if (binding.calibPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }

    private fun faceVisible() = SystemClock.uptimeMillis() - lastFaceMs < 500

    private fun startRecommendation() {
        if (!faceVisible()) {
            toast(getString(R.string.need_face))
            return
        }
        classifier.reset()
        sampling = true
    }

    private fun showRecommendation(result: io.leniot.hairtryon.face.FaceShapeResult?) {
        if (result == null) {
            toast(getString(R.string.need_face))
            return
        }
        val styles = HairCatalog.recommend(result)
        MaterialAlertDialogBuilder(this)
            .setTitle(getString(R.string.recommend_title, result.shape.label, result.length.label))
            .setItems(styles.map { it.name }.toTypedArray()) { _, which ->
                currentCategory = null
                (binding.categoryChips.getChildAt(0) as Chip).isChecked = true
                renderStyleChips()
                selectStyle(styles[which])
            }
            .setNegativeButton(R.string.btn_close, null)
            .show()
        toast(getString(R.string.recommend_note))
    }

    private fun capture() {
        val camera = binding.previewView.bitmap
        if (camera == null) {
            toast(getString(R.string.photo_failed))
            return
        }
        binding.btnCapture.isEnabled = false
        renderer.requestSnapshot { hair ->
            ioExecutor.execute {
                val uri = PhotoSaver.save(this, PhotoSaver.compose(camera, hair))
                runOnUiThread {
                    binding.btnCapture.isEnabled = true
                    if (uri == null) {
                        toast(getString(R.string.photo_failed))
                    } else {
                        Snackbar.make(binding.root, R.string.photo_saved, Snackbar.LENGTH_LONG)
                            .setAnchorView(binding.bottomPanel)
                            .setAction(R.string.share) {
                                startActivity(PhotoSaver.shareIntent(uri, getString(R.string.share_title)))
                            }
                            .show()
                    }
                }
            }
        }
    }

    // ---------- Kalibrasi ----------

    private fun setupCalibration() {
        val range = Calibration.OFFSET_RANGE_CM
        fun offsetToProgress(v: Float) = ((v + range) * 10f).roundToInt()
        fun progressToOffset(p: Int) = p / 10f - range
        fun scaleToProgress(s: Float) = ((s - Calibration.SCALE_MIN) * 100f).roundToInt()
        fun progressToScale(p: Int) = Calibration.SCALE_MIN + p / 100f

        fun sync() {
            binding.seekY.progress = offsetToProgress(calibration.offsetY)
            binding.seekZ.progress = offsetToProgress(calibration.offsetZ)
            binding.seekScale.progress = scaleToProgress(calibration.scale)
        }

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                calibration = when (bar.id) {
                    R.id.seekY -> calibration.copy(offsetY = progressToOffset(progress))
                    R.id.seekZ -> calibration.copy(offsetZ = progressToOffset(progress))
                    else -> calibration.copy(scale = progressToScale(progress))
                }
                renderer.calibration = calibration
            }

            override fun onStartTrackingTouch(bar: SeekBar) = Unit
            override fun onStopTrackingTouch(bar: SeekBar) = calibration.save(this@MainActivity)
        }
        binding.seekY.setOnSeekBarChangeListener(listener)
        binding.seekZ.setOnSeekBarChangeListener(listener)
        binding.seekScale.setOnSeekBarChangeListener(listener)
        binding.btnCalibReset.setOnClickListener {
            calibration = Calibration()
            renderer.calibration = calibration
            calibration.save(this)
            sync()
        }
        sync()
    }

    // ---------- Util ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private const val RECOMMEND_SAMPLES = 20
        private const val MAX_DISTANCE_CM = 75f
        private const val MAX_YAW_DEG = 35f
    }
}
